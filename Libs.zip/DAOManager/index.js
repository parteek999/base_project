/**
 * Created by Shumi on 13/01/18.
 */
'use strict';

module.exports = {
    queries : require('./queries')
};