/**
 * Created by Shumi on 17/5/18.
 */
'use strict';
module.exports = [
    require('./swagger'),
    require('./authToken'),
];

