/**
 * Created by Shumi on 17/5/18.
 */
module.exports = {
        Admins: require('./Admins'),
        Branchs: require('./Branchs'),
        Users: require('./Users'),
        Categories: require('./Categories'),
        Stocks: require('./Stocks'),
        Mixtures: require('./Mixtures'),
        Citys: require('./Citys'),
        Captain: require('./Captain'),
        Table: require('./Table'),
        Order: require('./Order'),
        BotContent: require('./BotContent'),
        Scratch: require('./Scratch'),

        

};