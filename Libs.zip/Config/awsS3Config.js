'use strict';
const s3BucketCredentials = {
    "bucket": "",
    "accessKeyId": "",
    "secretAccessKey": "/9M2vJ81mq+4Nw6L6XQug0R9h",
    "s3URL": "",
    "folder": {
        "original": "original",
        "thumbnail": "thumbnail",
        "processed": "processed",
        "thumbnail1080": "thumbnail1080",
        "thumbnailMed": "thumbnailMed"
    }
};

module.exports = {
    // s3BucketCredentials: s3BucketCredentials
};
