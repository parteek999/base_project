/**
 * Created by Shumi on 18/6/18.
 */
'use strict';
var nodeMailer = {

        auth: {
            user: "",
            pass: ""
        }
};
module.exports = {
    nodeMailer: nodeMailer
};